# Custom-python-libraries

Dear visitor,

Here are some libraries I made for myself.
I try to mention the source each time the code is not from me.
But I am not a computer scientist.
So there are obsviously much (much (much (...))) more efficient ways to do the job.

However if it helps you in any way, then it's perfect.
Feel free to use it, suggest things, reach me !

Best,
